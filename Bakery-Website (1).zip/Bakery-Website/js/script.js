// Sweet Crumbs Bakery — interactive features

// IMPORTANT: Replace this sample number with your WhatsApp number.
// Use country code + number, without +, spaces or dashes.
// Example for India: 919876543210
const WHATSAPP_NUMBER = "919876543210";

// Open WhatsApp with the selected product in the message.
document.querySelectorAll(".order-button").forEach((button) => {
  button.addEventListener("click", () => {
    const productName = button.dataset.product;
    const message = `Hello Sweet Crumbs! I would like to order: ${productName}. Please share the details.`;
    const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;

    if (WHATSAPP_NUMBER === "919876543210") {
      alert("Demo number is currently set. Open js/script.js and replace WHATSAPP_NUMBER with your bakery's WhatsApp number.");
      return;
    }
    window.open(whatsappUrl, "_blank", "noopener,noreferrer");
  });
});

// Mobile navigation menu.
const menuToggle = document.getElementById("menuToggle");
const nav = document.getElementById("nav");

menuToggle.addEventListener("click", () => {
  const isOpen = nav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
  menuToggle.textContent = isOpen ? "✕" : "☰";
});

nav.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    nav.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.setAttribute("aria-label", "Open navigation");
    menuToggle.textContent = "☰";
  });
});

// Automatically show the current year in the footer.
document.getElementById("year").textContent = new Date().getFullYear();
