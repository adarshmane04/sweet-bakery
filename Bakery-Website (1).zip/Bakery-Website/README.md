# Sweet Crumbs Bakery Website

A responsive bakery shop landing page built with plain HTML, CSS and JavaScript.

## Project structure

```text
Bakery-Website/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── script.js
└── README.md
```

## How to open in VS Code

1. Extract `Bakery-Website.zip`.
2. Open Visual Studio Code.
3. Select **File → Open Folder**.
4. Choose the extracted `Bakery-Website` folder.
5. Open `index.html`.
6. Right-click inside the editor and choose **Open with Live Server** (if you have the Live Server extension).
7. If you do not use Live Server, open `index.html` directly in Chrome or Edge.

## Before using it for a real bakery

1. Open `js/script.js`.
2. Find `const WHATSAPP_NUMBER = "919876543210";`.
3. Replace the sample number with the bakery WhatsApp number, including country code, without `+`, spaces or dashes. Example: `919876543210`.
4. In `index.html`, replace the sample address, phone number and email in the Contact section.
5. Update product names, prices and photos as required.

## Features

- Responsive layout for desktop and mobile
- Home, menu, story and contact sections
- Product cards with sample prices
- WhatsApp order buttons
- Mobile navigation menu
- Current year in footer

## Notes

- Google Fonts and product photos load from the internet, so an internet connection is needed for those assets.
- The prices and contact details are examples. This is a front-end demo; it does not include a database, admin panel, cart or online payment gateway.
